#encoding: utf-8

require_relative 'Damage'
require_relative 'WeaponType'
require_relative 'Weapon'

module P3
  class ExamenP3
    def principal
      daño = Deepspace::Damage.newCuantasPierde
      puts "Pierdo " + daño.nWeapons.to_s + " armas y " + daño.nShields.to_s + " escudos."

      arraywt = [Deepspace::WeaponType::LASER, Deepspace::WeaponType::LASER, Deepspace::WeaponType::PLASMA, Deepspace::WeaponType::PLASMA, Deepspace::WeaponType::MISSILE, Deepspace::WeaponType::MISSILE, Deepspace::WeaponType::ONEPUNCH, Deepspace::WeaponType::ONEPUNCH]
      dañonuevo = Deepspace::Damage.newSpecificWeapons(arraywt, 0)
      arrayw = [Deepspace::Weapon.new("Arma1", Deepspace::WeaponType::LASER, 2), Deepspace::Weapon.new("Arma2", Deepspace::WeaponType::PLASMA, 2),Deepspace::Weapon.new("Arma3", Deepspace::WeaponType::PLASMA, 2),Deepspace::Weapon.new("Arma4", Deepspace::WeaponType::PLASMA, 2),Deepspace::Weapon.new("Arma5", Deepspace::WeaponType::ONEPUNCH, 2),Deepspace::Weapon.new("Arma6", Deepspace::WeaponType::ONEPUNCH, 2)]

      dañoajustado = dañonuevo.adjust(arrayw, [])

      puts "Ajustado: " + dañoajustado.inspect
      puts dañoajustado.weapons

    end
  end
end

P3::ExamenP3.new.principal