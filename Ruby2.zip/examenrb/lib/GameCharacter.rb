#encoding: utf-8

#Enumerado que representa a los dos tipos de personajes del juego

module Deepspace
  module GameCharacter
    ENEMYSTARSHIP = :enemystarship
    SPACESTATION = :spacestation
  end
end
