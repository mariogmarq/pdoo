#encoding: utf-8

require_relative 'Damage'
require_relative 'WeaponType'
require_relative 'Weapon'

module P3
  class ExamenP3
    def imprimir(elemento, caracter)
      puts "Daño" + caracter.to_s + ": " + elemento.inspect
    end
    def principal
      daño1 = Deepspace::Damage.newCuantasPierde
      daño2 = Deepspace::Damage.newCuantasPierde
      daño3 = Deepspace::Damage.newCuantasPierde
      imprimir(daño1, "1")
      imprimir(daño2, "2")
      imprimir(daño3, "3")


      arraywt = [Deepspace::WeaponType::LASER, Deepspace::WeaponType::LASER, Deepspace::WeaponType::PLASMA, Deepspace::WeaponType::PLASMA, Deepspace::WeaponType::MISSILE, Deepspace::WeaponType::MISSILE, Deepspace::WeaponType::ONEPUNCH, Deepspace::WeaponType::ONEPUNCH]
      dañonuevo = Deepspace::Damage.newSpecificWeapons(arraywt, 0)
      arrayw = [Deepspace::Weapon.new("Arma1", Deepspace::WeaponType::LASER, 2), Deepspace::Weapon.new("Arma2", Deepspace::WeaponType::PLASMA, 2),Deepspace::Weapon.new("Arma3", Deepspace::WeaponType::PLASMA, 2),Deepspace::Weapon.new("Arma4", Deepspace::WeaponType::PLASMA, 2),Deepspace::Weapon.new("Arma5", Deepspace::WeaponType::ONEPUNCH, 2),Deepspace::Weapon.new("Arma6", Deepspace::WeaponType::ONEPUNCH, 2)]

      dañoajustado = dañonuevo.adjust(arrayw, [])

      imprimir(dañoajustado, "Ajustado")
      puts dañoajustado.weapons

    end
  end
end

P3::ExamenP3.new.principal