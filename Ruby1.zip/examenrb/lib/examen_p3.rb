#encoding: utf-8

require_relative 'Damage'

module P3
  class ExamenP3
    def principal
      daño = Deepspace::Damage.newCuantasPierde
      puts "Pierdo " + daño.nWeapons.to_s + " armas y " + daño.nShields.to_s + " escudos."
    end
  end
end

P3::ExamenP3.new.principal